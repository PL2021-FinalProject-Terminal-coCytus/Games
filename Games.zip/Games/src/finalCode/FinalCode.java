package finalCode;

import java.util.Scanner;

public class FinalCode {
	
	public static void main(String[] args){
		
		int L = 1,H = 1000;
		int key = (int)(Math.random()*999+1);
		int guess = 0;
		int count = 0;
				
	    Scanner scan = new Scanner(System.in);
		System.out.println("Final Code Game Start!");
		
		do{
	     System.out.println("Range:"+L+"~"+H);
	     System.out.print("Please enter a number: ");
	     guess = scan.nextInt();
	     count++;
	     
	     if(guess > key) {
	    	 H = guess;
	     }else {
	    	 L = guess;
	     }
		}
		
		while(key != guess);
		
		System.out.println("Bingo! You tried "+count+" times.");
	}
	
}
